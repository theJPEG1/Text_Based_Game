#include "Actions.H"

Actions::Actions(Player& p)
{
    player = p;

    actionMap["buyItems"] = std::bind(&Actions::buyItems, this);
    actionMap["craftItems"] = std::bind(&Actions::craftItems, this);
    actionMap["hearRumor"] = std::bind(&Actions::rumors, this);;
    actionMap["sellItems"] = std::bind(&Actions::sellItems, this);
    actionMap["viewGuildCard"] = std::bind(&Actions::viewGuildCard, this);
    actionMap["viewInventory"] = std::bind(&Actions::viewInventory, this);
    actionMap["effectView"] = std::bind(&Actions::printEffectList, this);
    actionMap["wellTalk"] = std::bind(&Actions::wellTalk, this);
    actionMap["tossInACoin"] = std::bind(&Actions::tossInACoin, this);

    actionMap["fight"] = std::bind(&Actions::fight, this);

    actionMap["healthPotion"] = std::bind(&Actions::addHealthPots, this);
    actionMap["manaPotion"] = std::bind(&Actions::addManaPots, this);
    

    loadCraftingMats("GameData/craftingMaterials.json");
    loadAllAttacks("playerData/PlayerAction/attacks.json");

    //incialize a map of crafting mats and of attakcs
    // Map <string id, craftingMats mat>
    // Map <string id, Attacks atk>

};

void Actions::loadCraftingMats(string fileLocation)
{
    CraftingMaterials cLoad;

    vector<CraftingMaterials> cMats = cLoad.loadCraftingMaterialss(fileLocation);

    for(size_t i = 0; i < cMats.size(); i++)
    {
        materials[cMats.at(i).id] = cMats.at(i);
    }
};

void Actions::loadAllAttacks(string fileLocation)
{
    Attacks load;

    vector<Attacks> attacksFile = load.loadAttacks(fileLocation);

    for(size_t i = 0; i < attacksFile.size(); i++)
    {
        playerAttacks[attacksFile.at(i).id] = attacksFile.at(i);
    }
};

void Actions::loadAreaFromJson(string jsonToLoad)
{
    color.clearScreen();

    jsonToLoad = "Locations/" + jsonToLoad;

    ifstream file(jsonToLoad);

    if (!file.is_open()) {
        cout << "Failed to open " << jsonToLoad << "\n";
        return;
    }

    currentJson = jsonToLoad;

    json data;
    file >> data;

    string header = data["header"];

    json actions = data["Actions"];

    int keyboardInput = 0;
    while(keyboardInput <= 0 || keyboardInput > actions.size())
    {
        cout << "\n" << header << "\n";

        for (size_t i = 0; i < actions.size(); ++i)
        {
            if(actions.size() <= 4)
            {
                if(i % 2 == 0)
                {
                    cout << "\n";
                }
            }
            else
            {
                if(i % 3 == 0)
                {
                    cout << "\n";
                }
            }

            string actionPrint = actions[i]["actionDescription"];
            cout << actionPrint;

            if(actionPrint.length() < 30 && actionPrint.length() > 17)
            {
                cout << "\t";
            }

            if(actionPrint.length() < 16)
            {
                cout << "\t";
            }

            if(actionPrint.length() < 8)
            {
                cout << "\t";
            }
        
        }

        cout << "\n-> ";

        cin >> keyboardInput;

        string actionToCheck = actions[keyboardInput-1]["target"];

        if(actionToCheck.substr(actionToCheck.length() - 5, 5) == ".json")
        {
            file.close();
            loadAreaFromJson(actionToCheck);
        }

        else
        {
            actionMap.find(actionToCheck)->second();
        }

        keyboardInput = 0;
        
    }

    file.close();
    color.clearScreen();
};

void Actions::buyItems()
{
    color.clearScreen();

    ifstream file(currentJson);

    if (!file.is_open()) {
        cout << "Failed to open " << currentJson << "\n";
        return;
    }


    json data;
    file >> data;

    string type = data["type"];
    string buyMessage = data["buyMessage"];

    json inventory = data["Inventory"];

    int keyboardInput = 0;

    while(keyboardInput <= 0 || keyboardInput > inventory.size())
    {
        cout << "\n" << buyMessage << "\n";
        cout << "You have " << player.getNovas() << " Novas.\n";

        for (size_t i = 0; i < inventory.size(); ++i)
        {
            if(inventory.size() <= 4)
            {
                if(i % 2 == 0)
                {
                    cout << "\n";
                }
            }
            else
            {
                if(i % 3 == 0)
                {
                    cout << "\n";
                }
            }

            string actionDesc = inventory[i]["actionDescription"];
            cout << actionDesc;

            if(!inventory[i]["Cost"].is_null())
            {
                int cost = inventory[i]["Cost"];
                cout << " | " << cost << " Novas\t";

                if(actionDesc.length() < 10)
                {
                    cout << "\t";
                }
            }

            else
            {
                cout << "\t";
            }
        }

        cout << "\n-> ";

        cin >> keyboardInput;

        if(!inventory[keyboardInput - 1]["Cost"].is_null())
        {
            if(player.getNovas() >= inventory[keyboardInput - 1]["Cost"])
            {
                int cost = inventory[keyboardInput - 1]["Cost"];
                player.increaseNovas(-cost);

                string idToLocation = inventory[keyboardInput - 1]["ID"];

                if(type == "blacksmith")
                {
                    player.addCombatAttacks(playerAttacks.find(idToLocation)->second);
                    player.setSpecificSlot(playerAttacks.find(idToLocation)->second, 0);
                }

                else if(type == "shop")
                {
                    potionsToAdd = inventory[keyboardInput - 1]["Amt"];
                }
            }
        }
    }

    loadAreaFromJson("Locations/" + currentJson);

    color.clearScreen();
};

void Actions::craftItems()
{
    CraftingMaterials cLoad;

    vector<CraftingMaterials> cMats = cLoad.loadCraftingMaterialss("GameData/craftingMaterials.json");

    color.clearScreen();

    ifstream file(currentJson);

    if (!file.is_open()) {
        cout << "Failed to open " << currentJson << "\n";
        return;
    }


    json data;
    file >> data;

    string type = data["type"];
    string craftMes = data["craftMessage"];
    int maxRare = data["maxRarity"];

    string keyboardString = "";
    player.printInventory(maxRare);

    vector <CraftingMaterials> crafting;

    int count = 0;
    bool matAdded = false;
    cout << "\nPick a material (BACK to go back)";
    

    while(count < 3 && keyboardString != "BACK")
    {
        cout << "\n-> ";
        getline(cin, keyboardString);
        
        for(size_t i = 0; i < cMats.size(); i++)
        {
            if(matAdded == false)
            {
                if(keyboardString == cMats.at(i).name )
                {
                    crafting.push_back(cMats.at(i));
                    matAdded = true;
                    count++;
                }
            }
        }

        matAdded = false;

        cout << "\n";
    }

    if(keyboardString != "BACK")
    {
        Attacks customAtk = customAtk.createAttack(crafting.at(0), crafting.at(1), crafting.at(2));
    
        player.addCustomAtk(customAtk);

        if(customAtk.type == "spell")
        {
            player.addCombatSpells(customAtk);
            player.setSpecificSlot(customAtk, 4);
        }

        else if(customAtk.type == "attack")
        {
            player.addCombatAttacks(customAtk);
            player.setSpecificSlot(customAtk, 0);
        }

        cout << "Custom attack created and Slotted\n";

        for(size_t i = 0; i < crafting.size(); i++)
        {
            player.addToInventory(cMats.at(i), -1);
        }
    }

    
}

void Actions::sellItems()
{
    CraftingMaterials cLoad;

    vector<CraftingMaterials> cMats = cLoad.loadCraftingMaterialss("GameData/craftingMaterials.json");
    CraftingMaterials sellMat;

    color.clearScreen();

    ifstream file(currentJson);

    if (!file.is_open()) {
        cout << "Failed to open " << currentJson << "\n";
        return;
    }


    json data;
    file >> data;

    string sellMes = data["sellMessage"];

    cout << sellMes << "\n";

    player.printInventory(1000);

    cout << "\nWhat would you like to sell? (BACK to go back)\n-> ";

    string keyboardString = "";
    int keyboardInput = 0;
    bool matAdded = false;
    bool itemSold = false;

    cin.ignore();
    getline(cin, keyboardString);

    if(keyboardString != "BACK")
    {
        for(size_t i = 0; i < cMats.size(); i++)
        {
            if(matAdded == false)
            {
                if(keyboardString == cMats.at(i).name )
                {
                    sellMat = cMats.at(i);
                    matAdded = true;
                }

                else
                {
                    sellMat.name = "NotFound";
                }
            }
        }

        if(sellMat.name != "NotFound")
        {
            cout << "\nHow many? That one is worth " << sellMat.price << " novas.";

            while(!itemSold)
            {
                cout << "\n-> ";
                cin >> keyboardInput;

                if(keyboardInput > 0 && keyboardInput <= player.getInventoryAmount(sellMat))
                {
                    player.addToInventory(sellMat, -keyboardInput);
                    int novasToAdd = sellMat.price * keyboardInput;

                    cout << "You made " << novasToAdd << " Novas!\n";
                    player.increaseNovas(novasToAdd);
                    itemSold = true;
                }

                else
                {
                    cout << "\n! INVALID AMOUNT !\n";
                    keyboardInput = 0;
                }
            }
        }

        else
        {
            cout << "\n! INVALID MATERIAL NAME !\n";
        }
    }
};

void Actions::rumors()
{
    cout << "\n<INSERT RUMOR HERE>\n";
};

void Actions::viewGuildCard()
{
    color.clearScreen();
    player.printGuildCard();
    cout << "\n";
};

void Actions::viewInventory()
{
    color.clearScreen();
    player.printInventory(1000);
    cout << "\n";
};

void Actions::printEffectList()
{
    color.clearScreen();
    for(size_t i = 0; i < effects.size(); i++)
    {
        cout << effects.at(i) << "\t";

        if(effects.at(i).length() <= 6)
        {
            cout << "\t";
        }

        if (i % 2 == 0) 
        {
            std::cout << "\n";
        }
    }
};

void Actions::wellTalk()
{
    color.clearScreen();

    vector<string> wellTalks =
    {
        "Some say that this well is encahnted.\nA coin for a wish.\nI don't believe it though.\n",
        "I heard that there is a goblin that set up this well.\nIt's all just a ploy so he can get rich!\n",
        "I tossed in a coin and I feel better.\nStronger, faster, luckier, just all of it, better!\n",
        "I wonder what's at the bottom of the well?\nIt just looks like it goes on forever.\n", //quest start for bottom of the well option
        "This well is a curse on the town. People come and throw coins expecting riches.\nI know better!\n"
    };

    //better message logic so i can skew things
    string message = wellTalks.at(rand() % wellTalks.size());

    if(message == wellTalks.at(3))
    {
        //start the bottom of the well quest
    }

    //logic to add as a quest

    cout << message;
};

void Actions::tossInACoin()
{

    ifstream file(currentJson);

    if (!file.is_open()) {
        cout << "Failed to open " << currentJson << "\n";
        return;
    }

    json data;
    file >> data;

    json outData;
    file.close();

   

    int curCoinAmt = data.value("coinAmt", 0);

    if(player.getNovas() > 0 && curCoinAmt <= 5025)
    {
        player.increaseNovas(-1);

        curCoinAmt++;

        if(curCoinAmt >= 5000)
        {
            int chanceEncounter = (rand() % 100 + 1) - player.getLuck();
            if(chanceEncounter > 10)
            {
                cout << "You watch as your coin floats down the well, with nothing in return.\n";
            }

            else if(chanceEncounter <= 10 && chanceEncounter > 5)
            {
                int whichStat = rand() % 5 + 1;

                if(whichStat == 1)
                {
                    cout << "Your health increases!\n";
                    player.increaseMaxHealth(1);
                }

                else if(whichStat == 2)
                {
                    cout << "Your strength increases!\n";
                    player.increaseStrength(1);
                }

                else if(whichStat == 3)
                {
                    cout << "Your dexterity increases!\n";
                    player.increaseDexterity(1);
                }

                else if(whichStat == 4)
                {
                    cout << "Your mind increases!\n";
                    player.increaseMind(1);
                }

                else if(whichStat == 5)
                {
                    cout << "Your luck increases!\n";
                    player.increaseLuck(1);
                }
            }

            else 
            {
                cout << "Everything grow stronger!\n";
                    player.increaseMaxHealth(1);
                    player.increaseStrength(1);
                    player.increaseDexterity(1);
                    player.increaseMind(1);
                    player.increaseLuck(1);
            }
        }

        else if( curCoinAmt < 5000 && curCoinAmt >= 2000)
        {
            int chanceEncounter = (rand() % 100 + 1) - player.getLuck();
            if(chanceEncounter > 7)
            {
                cout << "You watch as your coin floats down the well, with nothing in return.\n";
            }

            else if(chanceEncounter <= 7 && chanceEncounter > 3)
            {
                int whichStat = rand() % 4 + 1;

                if(whichStat == 1)
                {
                    cout << "Your health increases!\n";
                    player.increaseMaxHealth(1);
                }

                else if(whichStat == 2)
                {
                    cout << "Your strength increases!\n";
                    player.increaseStrength(1);
                }

                else if(whichStat == 3)
                {
                    cout << "Your dexterity increases!\n";
                    player.increaseDexterity(1);
                }

                else if(whichStat == 4)
                {
                    cout << "Your mind increases!\n";
                    player.increaseMind(1);
                }
            }

            else 
            {
                cout << "Everything grow stronger!\n";
                    player.increaseMaxHealth(1);
                    player.increaseStrength(1);
                    player.increaseDexterity(1);
                    player.increaseMind(1);
            }
        }

        else if(curCoinAmt < 2000)
        {
            int chanceEncounter = (rand() % 100 + 1) + player.getLuck();

            if(chanceEncounter < 96)
            {
                cout << "You watch as your coin floats down the well, with nothing in return.\n";
            }

            else if(chanceEncounter >= 96 && chanceEncounter < 99)
            {
                int whichStat = rand() % 4 + 1;

                if(whichStat == 1)
                {
                    cout << "Your health increases!\n";
                    player.increaseMaxHealth(1);
                }

                else if(whichStat == 2)
                {
                    cout << "Your strength increases!\n";
                    player.increaseStrength(1);
                }

                else if(whichStat == 3)
                {
                    cout << "Your dexterity increases!\n";
                    player.increaseDexterity(1);
                }

                else if(whichStat == 4)
                {
                    cout << "Your mind increases!\n";
                    player.increaseMind(1);
                }
            }

            else 
            {
                cout << "Everything grow stronger!\n";
                    player.increaseMaxHealth(1);
                    player.increaseStrength(1);
                    player.increaseDexterity(1);
                    player.increaseMind(1);
            }
        }
    }

    else if(curCoinAmt >= 5025)
    {
        cout << "The well once full of water is now replaced with Silver Novas.\n";
    }

    else
    {
        cout << "You stare at the water wishing you had a coin.\n";
    }


    data["coinAmt"] = curCoinAmt;
    ofstream outFile(currentJson);
    outFile << data.dump(4);
    outFile.close();

    Saving::saveToFile(player, "playerData/playerStatsSave.json", "playerData/playerCombatBook.json");
    Saving::saveAttacks("playerData/PlayerAction/customAttacks.json", player.getCustomAtks());

    color.pauseTerminal(3);
    color.clearScreen();
};

void Actions::fight()
{
    player.increaseHealth(player.getMaxHealth());
    vector<vector<Enemy>> forest = EnemyFactory::loadRegionEnemy("Forest");

    Combat forestCombat(player, forest, "Forest");

    forestCombat.determineEnemy();
    //forestCombat.printGui();

    forestCombat.newCombatTest();

    cout << color.YELLOW << "You survived the encounter!\n" << color.DEFAULT;

    Saving::saveToFile(player, "playerData/playerStatsSave.json", "playerData/playerCombatBook.json");
    Saving::saveAttacks("playerData/PlayerAction/customAttacks.json", player.getCustomAtks());
};

void Actions::addHealthPots()
{
    player.increaseHealthPotionCount(potionsToAdd);
}

void Actions::addManaPots()
{
    player.increaseManaPotionCount(potionsToAdd);
}

